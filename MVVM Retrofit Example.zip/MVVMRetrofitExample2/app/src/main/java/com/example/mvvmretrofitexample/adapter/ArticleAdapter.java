package com.example.mvvmretrofitexample.adapter;

public class ArticleAdapter {
}
